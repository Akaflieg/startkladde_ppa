#!/usr/bin/env ruby

puts Dir.pwd

